# -*- coding: utf-8 -*-
import logging, sys
import logging
from python.routing.dijkstra import *
from python.utils.utils import *
from python.network.node import *

from python.routing.routing_protocol import *
from python.network.network import Network
import config as cf
net = Network()

class TRUST(list):
 # L1 = []
 # def level1():
 #   heads = network.get_heads()
  #  L1 = []
  #  for node in heads :
   #   if node.next_hop == cf.BSID :
    #    L1.append(node)

  def get_class_nodes(self) :
     
     nodes = network.get_ordinary_nodes()
     return [node for node in nodes if node.next_hop == self.id]
    
        
  def get_children_node(self) :

     heads = network.get_heads()
     return [node for node in heads if node.next_hop == self.id]
  def on_defens(self) :
     #logging.info('LEACHMTE: defens')
     net = network()
     heads = net.get_heads()
     L1 = []
     for node in heads :
       if node.next_hop == cf.BSID :
        L1.append(node)
     mn = []
     for node in L1 :
       tn_value = network.get_tn_value_forheads(node)
       if tn_value < 11 :
        mn.append(node) 
    
     for node in mn :
       child = node.get_children_node()
       group = node.get_class_nodes()
       for other in child :
         tn_value2 = network.get_tn_value_forheads(other)
         if tn_value2 < 11:
          mn.remove(node)
          mn.append(other)
         else :
          for dugme in group :
            tn_value3 = network.get_tn_value_forheads(dugme)
            if tn_value3< 11:
             mn.remove(node)
             mn.append(dugme)
        
     print ('malicious nodes:')
     print (mn)
