import config as cf
import logging

class EnergySource(object):
  def __init__(self, parent):
    if id == 7 or id == 9  :
      self.energy = cf.INITIAL_ENERGYattack
    elif id == 25 or id == 500 :
      self.energy = 2* cf.INITIAL_ENERGYattack
    else:
      self.energy = cf.INITIAL_ENERGY
      self.node = parent

  def recharge(self):
    self.energy = cf.INITIAL_ENERGY

class Battery(EnergySource):
  def consume(self, energy):
    if self.energy >= energy:
      self.energy -= energy
    else:
      logging.info("node %d: battery is depleted." % (self.node.id))
      self.energy = 0

      self.node.battery_depletion()

class PluggedIn(EnergySource):
  def consume(self, energy):
    pass

